package android.support.design;

/* renamed from: android.support.design.h */
public final class C0025h {

    /* renamed from: a */
    public static final int design_layout_snackbar = 2130968620;

    /* renamed from: b */
    public static final int design_layout_snackbar_include = 2130968621;

    /* renamed from: c */
    public static final int design_navigation_menu_item = 2130968630;
}
