package android.support.design;

/* renamed from: android.support.design.f */
public final class C0023f {

    /* renamed from: a */
    public static final int design_menu_item_action_area_stub = 2131624141;

    /* renamed from: b */
    public static final int design_menu_item_text = 2131624140;

    /* renamed from: c */
    public static final int snackbar_action = 2131624137;

    /* renamed from: d */
    public static final int snackbar_text = 2131624136;
}
