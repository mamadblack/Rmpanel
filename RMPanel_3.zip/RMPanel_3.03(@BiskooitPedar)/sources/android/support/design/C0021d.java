package android.support.design;

/* renamed from: android.support.design.d */
public final class C0021d {

    /* renamed from: a */
    public static final int design_bottom_sheet_peek_height_min = 2131296356;

    /* renamed from: b */
    public static final int design_fab_size_mini = 2131296360;

    /* renamed from: c */
    public static final int design_fab_size_normal = 2131296361;

    /* renamed from: d */
    public static final int design_navigation_icon_size = 2131296365;

    /* renamed from: e */
    public static final int design_snackbar_padding_vertical = 2131296370;

    /* renamed from: f */
    public static final int design_snackbar_padding_vertical_2lines = 2131296278;
}
