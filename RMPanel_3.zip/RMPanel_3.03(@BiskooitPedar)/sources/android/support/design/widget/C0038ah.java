package android.support.design.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;

/* renamed from: android.support.design.widget.ah */
public abstract class C0038ah<V extends View> {
    public C0038ah() {
    }

    public C0038ah(Context context, AttributeSet attributeSet) {
    }

    /* renamed from: a */
    public void mo269a(C0041ak akVar) {
    }

    /* renamed from: a */
    public boolean mo203a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        return false;
    }

    /* renamed from: b */
    public boolean mo206b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        return false;
    }

    /* renamed from: a_ */
    public boolean mo197a_(View view) {
        return false;
    }

    /* renamed from: b */
    public boolean mo199b(CoordinatorLayout coordinatorLayout, V v, View view) {
        return false;
    }

    /* renamed from: a */
    public boolean mo188a(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3, int i4) {
        return false;
    }

    /* renamed from: a */
    public boolean mo187a(CoordinatorLayout coordinatorLayout, V v, int i) {
        return false;
    }

    /* renamed from: a */
    public boolean mo189a(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
        return false;
    }

    /* renamed from: a */
    public void mo183a(CoordinatorLayout coordinatorLayout, V v, View view) {
    }

    /* renamed from: b */
    public void mo192b(CoordinatorLayout coordinatorLayout, V v, int i) {
    }

    /* renamed from: a */
    public void mo184a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int[] iArr) {
    }

    /* renamed from: a */
    public boolean mo186a(CoordinatorLayout coordinatorLayout, V v, float f, boolean z) {
        return false;
    }

    /* renamed from: a */
    public boolean mo204a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        return false;
    }

    /* renamed from: a */
    public boolean mo196a(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean z) {
        return false;
    }

    /* renamed from: a */
    public void mo182a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
    }

    /* renamed from: b */
    public Parcelable mo191b(CoordinatorLayout coordinatorLayout, V v) {
        return BaseSavedState.EMPTY_STATE;
    }

    /* renamed from: a */
    public boolean mo270a(V v, Rect rect) {
        return false;
    }
}
