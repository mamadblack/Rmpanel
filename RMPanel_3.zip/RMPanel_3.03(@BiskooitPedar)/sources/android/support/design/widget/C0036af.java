package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.support.p003v4.p006b.C0237a;

/* renamed from: android.support.design.widget.af */
final class C0036af extends Drawable {

    /* renamed from: a */
    final Paint f292a;

    /* renamed from: b */
    final Rect f293b;

    /* renamed from: c */
    final RectF f294c;

    /* renamed from: d */
    float f295d;

    /* renamed from: e */
    private int f296e;

    /* renamed from: f */
    private int f297f;

    /* renamed from: g */
    private int f298g;

    /* renamed from: h */
    private int f299h;

    /* renamed from: i */
    private ColorStateList f300i;

    /* renamed from: j */
    private int f301j;

    /* renamed from: k */
    private boolean f302k;

    /* renamed from: l */
    private float f303l;

    public final void draw(Canvas canvas) {
        if (this.f302k) {
            Paint paint = this.f292a;
            Rect rect = this.f293b;
            copyBounds(rect);
            float height = this.f295d / ((float) rect.height());
            paint.setShader(new LinearGradient(0.0f, (float) rect.top, 0.0f, (float) rect.bottom, new int[]{C0237a.m791a(this.f296e, this.f301j), C0237a.m791a(this.f297f, this.f301j), C0237a.m791a(C0237a.m793b(this.f297f, 0), this.f301j), C0237a.m791a(C0237a.m793b(this.f299h, 0), this.f301j), C0237a.m791a(this.f299h, this.f301j), C0237a.m791a(this.f298g, this.f301j)}, new float[]{0.0f, height, 0.5f, 0.5f, 1.0f - height, 1.0f}, TileMode.CLAMP));
            this.f302k = false;
        }
        float strokeWidth = this.f292a.getStrokeWidth() / 2.0f;
        RectF rectF = this.f294c;
        copyBounds(this.f293b);
        rectF.set(this.f293b);
        rectF.left += strokeWidth;
        rectF.top += strokeWidth;
        rectF.right -= strokeWidth;
        rectF.bottom -= strokeWidth;
        canvas.save();
        canvas.rotate(this.f303l, rectF.centerX(), rectF.centerY());
        canvas.drawOval(rectF, this.f292a);
        canvas.restore();
    }

    public final boolean getPadding(Rect rect) {
        int round = Math.round(this.f295d);
        rect.set(round, round, round, round);
        return true;
    }

    public final void setAlpha(int i) {
        this.f292a.setAlpha(i);
        invalidateSelf();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo286a(ColorStateList colorStateList) {
        if (colorStateList != null) {
            this.f301j = colorStateList.getColorForState(getState(), this.f301j);
        }
        this.f300i = colorStateList;
        this.f302k = true;
        invalidateSelf();
    }

    public final void setColorFilter(ColorFilter colorFilter) {
        this.f292a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public final int getOpacity() {
        return this.f295d > 0.0f ? -3 : -2;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo285a(float f) {
        if (f != this.f303l) {
            this.f303l = f;
            invalidateSelf();
        }
    }

    /* access modifiers changed from: protected */
    public final void onBoundsChange(Rect rect) {
        this.f302k = true;
    }

    public final boolean isStateful() {
        return (this.f300i != null && this.f300i.isStateful()) || super.isStateful();
    }

    /* access modifiers changed from: protected */
    public final boolean onStateChange(int[] iArr) {
        if (this.f300i != null) {
            int colorForState = this.f300i.getColorForState(iArr, this.f301j);
            if (colorForState != this.f301j) {
                this.f302k = true;
                this.f301j = colorForState;
            }
        }
        if (this.f302k) {
            invalidateSelf();
        }
        return this.f302k;
    }
}
