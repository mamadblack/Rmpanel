package android.support.design.widget;

import android.os.Parcel;
import android.support.p003v4.p017os.C0429d;

/* renamed from: android.support.design.widget.an */
final class C0044an implements C0429d<C0043am> {
    C0044an() {
    }

    /* renamed from: a */
    public final /* bridge */ /* synthetic */ Object[] mo282a(int i) {
        return new C0043am[i];
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo281a(Parcel parcel, ClassLoader classLoader) {
        return new C0043am(parcel, classLoader);
    }
}
