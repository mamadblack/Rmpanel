package android.support.design.widget;

import android.support.p003v4.p014g.C0403d;
import android.support.p003v4.p014g.p015a.C0330l;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

/* renamed from: android.support.design.widget.ae */
final class C0035ae extends C0403d {

    /* renamed from: a */
    final /* synthetic */ CheckableImageButton f291a;

    C0035ae(CheckableImageButton checkableImageButton) {
        this.f291a = checkableImageButton;
    }

    /* renamed from: a */
    public final void mo284a(View view, AccessibilityEvent accessibilityEvent) {
        super.mo284a(view, accessibilityEvent);
        accessibilityEvent.setChecked(this.f291a.isChecked());
    }

    /* renamed from: a */
    public final void mo155a(View view, C0330l lVar) {
        super.mo155a(view, lVar);
        lVar.mo988a(true);
        lVar.mo991b(this.f291a.isChecked());
    }
}
