package android.support.design.widget;

import android.support.p003v4.p014g.p016b.C0372a;
import android.support.p003v4.p014g.p016b.C0373b;
import android.support.p003v4.p014g.p016b.C0374c;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

/* renamed from: android.support.design.widget.a */
final class C0030a {

    /* renamed from: a */
    static final Interpolator f280a = new LinearInterpolator();

    /* renamed from: b */
    static final Interpolator f281b = new C0373b();

    /* renamed from: c */
    static final Interpolator f282c = new C0372a();

    /* renamed from: d */
    static final Interpolator f283d = new C0374c();

    /* renamed from: e */
    static final Interpolator f284e = new DecelerateInterpolator();
}
