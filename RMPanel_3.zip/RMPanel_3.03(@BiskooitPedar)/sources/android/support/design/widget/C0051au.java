package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: android.support.design.widget.au */
final class C0051au extends AnimatorListenerAdapter {

    /* renamed from: a */
    final /* synthetic */ boolean f351a = false;

    /* renamed from: b */
    final /* synthetic */ C0056az f352b;

    /* renamed from: c */
    final /* synthetic */ C0050at f353c;

    /* renamed from: d */
    private boolean f354d;

    C0051au(C0050at atVar, C0056az azVar) {
        this.f353c = atVar;
        this.f352b = azVar;
    }

    public final void onAnimationStart(Animator animator) {
        this.f353c.f345m.mo383a(0, this.f351a);
        this.f354d = false;
    }

    public final void onAnimationCancel(Animator animator) {
        this.f354d = true;
    }

    public final void onAnimationEnd(Animator animator) {
        this.f353c.f338b = 0;
        if (!this.f354d) {
            this.f353c.f345m.mo383a(this.f351a ? 8 : 4, this.f351a);
        }
    }
}
