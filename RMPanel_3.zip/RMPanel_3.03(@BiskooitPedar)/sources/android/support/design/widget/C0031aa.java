package android.support.design.widget;

import android.support.p003v4.p014g.C0351ag;
import android.support.p003v4.widget.C0457ay;
import android.view.View;

/* renamed from: android.support.design.widget.aa */
final class C0031aa extends C0457ay {

    /* renamed from: a */
    final /* synthetic */ BottomSheetBehavior f285a;

    C0031aa(BottomSheetBehavior bottomSheetBehavior) {
        this.f285a = bottomSheetBehavior;
    }

    /* renamed from: a */
    public final boolean mo276a(View view, int i) {
        if (this.f285a.f213d == 1) {
            return false;
        }
        if (this.f285a.f219j) {
            return false;
        }
        if (this.f285a.f213d == 3 && this.f285a.f218i == i) {
            View view2 = (View) this.f285a.f217h.get();
            if (view2 != null && C0351ag.m1170a(view2, -1)) {
                return false;
            }
        }
        return this.f285a.f216g != null && this.f285a.f216g.get() == view;
    }

    /* renamed from: b */
    public final void mo277b(View view, int i) {
        this.f285a.mo201a();
    }

    /* renamed from: a */
    public final void mo274a(int i) {
        if (i == 1) {
            this.f285a.mo202a(1);
        }
    }

    /* renamed from: a */
    public final void mo275a(View view, float f, float f2) {
        int i;
        int i2 = 3;
        if (f2 < 0.0f) {
            i = this.f285a.f210a;
        } else if (this.f285a.f212c && this.f285a.mo205a(view, f2)) {
            i = this.f285a.f215f;
            i2 = 5;
        } else if (f2 == 0.0f) {
            int top = view.getTop();
            if (Math.abs(top - this.f285a.f210a) < Math.abs(top - this.f285a.f211b)) {
                i = this.f285a.f210a;
            } else {
                i = this.f285a.f211b;
                i2 = 4;
            }
        } else {
            i = this.f285a.f211b;
            i2 = 4;
        }
        if (this.f285a.f214e.mo1276a(view.getLeft(), i)) {
            this.f285a.mo202a(2);
            C0351ag.m1166a(view, (Runnable) new C0034ad(this.f285a, view, i2));
            return;
        }
        this.f285a.mo202a(i2);
    }

    /* renamed from: c */
    public final int mo278c(View view, int i) {
        return C0064bg.m260a(i, this.f285a.f210a, this.f285a.f212c ? this.f285a.f215f : this.f285a.f211b);
    }

    /* renamed from: d */
    public final int mo279d(View view, int i) {
        return view.getLeft();
    }

    /* renamed from: a */
    public final int mo273a() {
        if (this.f285a.f212c) {
            return this.f285a.f215f - this.f285a.f210a;
        }
        return this.f285a.f211b - this.f285a.f210a;
    }
}
