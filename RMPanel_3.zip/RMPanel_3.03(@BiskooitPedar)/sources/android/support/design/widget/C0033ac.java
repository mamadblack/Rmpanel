package android.support.design.widget;

import android.os.Parcel;
import android.support.p003v4.p017os.C0429d;

/* renamed from: android.support.design.widget.ac */
final class C0033ac implements C0429d<C0032ab> {
    C0033ac() {
    }

    /* renamed from: a */
    public final /* bridge */ /* synthetic */ Object[] mo282a(int i) {
        return new C0032ab[i];
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo281a(Parcel parcel, ClassLoader classLoader) {
        return new C0032ab(parcel, classLoader);
    }
}
