package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p003v4.p014g.C0300a;
import android.support.p003v4.p017os.C0427b;
import android.util.SparseArray;

/* renamed from: android.support.design.widget.am */
public final class C0043am extends C0300a {

    /* renamed from: b */
    public static final Creator<C0043am> f324b = C0427b.m1431a(new C0044an());

    /* renamed from: a */
    SparseArray<Parcelable> f325a;

    public C0043am(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        int readInt = parcel.readInt();
        int[] iArr = new int[readInt];
        parcel.readIntArray(iArr);
        Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
        this.f325a = new SparseArray<>(readInt);
        for (int i = 0; i < readInt; i++) {
            this.f325a.append(iArr[i], readParcelableArray[i]);
        }
    }

    public C0043am(Parcelable parcelable) {
        super(parcelable);
    }

    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        int i2 = this.f325a != null ? this.f325a.size() : 0;
        parcel.writeInt(i2);
        int[] iArr = new int[i2];
        Parcelable[] parcelableArr = new Parcelable[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            iArr[i3] = this.f325a.keyAt(i3);
            parcelableArr[i3] = (Parcelable) this.f325a.valueAt(i3);
        }
        parcel.writeIntArray(iArr);
        parcel.writeParcelableArray(parcelableArr, i);
    }
}
