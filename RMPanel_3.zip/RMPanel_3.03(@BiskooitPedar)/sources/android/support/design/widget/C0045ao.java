package android.support.design.widget;

import android.support.p003v4.p014g.C0351ag;
import android.view.View;
import java.util.Comparator;

/* renamed from: android.support.design.widget.ao */
final class C0045ao implements Comparator<View> {
    C0045ao() {
    }

    public final /* synthetic */ int compare(Object obj, Object obj2) {
        View view = (View) obj2;
        float x = C0351ag.m1197x((View) obj);
        float x2 = C0351ag.m1197x(view);
        if (x > x2) {
            return -1;
        }
        if (x < x2) {
            return 1;
        }
        return 0;
    }
}
