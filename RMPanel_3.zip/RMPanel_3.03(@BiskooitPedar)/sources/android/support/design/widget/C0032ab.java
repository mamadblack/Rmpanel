package android.support.design.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.p003v4.p014g.C0300a;
import android.support.p003v4.p017os.C0427b;

/* renamed from: android.support.design.widget.ab */
public final class C0032ab extends C0300a {

    /* renamed from: b */
    public static final Creator<C0032ab> f286b = C0427b.m1431a(new C0033ac());

    /* renamed from: a */
    final int f287a;

    public C0032ab(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f287a = parcel.readInt();
    }

    public C0032ab(Parcelable parcelable, int i) {
        super(parcelable);
        this.f287a = i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeInt(this.f287a);
    }
}
