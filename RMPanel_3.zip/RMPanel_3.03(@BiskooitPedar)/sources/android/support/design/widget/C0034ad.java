package android.support.design.widget;

import android.support.p003v4.p014g.C0351ag;
import android.view.View;

/* renamed from: android.support.design.widget.ad */
final class C0034ad implements Runnable {

    /* renamed from: a */
    final /* synthetic */ BottomSheetBehavior f288a;

    /* renamed from: b */
    private final View f289b;

    /* renamed from: c */
    private final int f290c;

    C0034ad(BottomSheetBehavior bottomSheetBehavior, View view, int i) {
        this.f288a = bottomSheetBehavior;
        this.f289b = view;
        this.f290c = i;
    }

    public final void run() {
        if (this.f288a.f214e == null || !this.f288a.f214e.mo1280b()) {
            this.f288a.mo202a(this.f290c);
        } else {
            C0351ag.m1166a(this.f289b, (Runnable) this);
        }
    }
}
