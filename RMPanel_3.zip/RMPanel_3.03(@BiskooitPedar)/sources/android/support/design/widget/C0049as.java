package android.support.design.widget;

import android.graphics.drawable.Drawable;

/* renamed from: android.support.design.widget.as */
final class C0049as implements C0066bi {

    /* renamed from: a */
    final /* synthetic */ FloatingActionButton f332a;

    C0049as(FloatingActionButton floatingActionButton) {
        this.f332a = floatingActionButton;
    }

    /* renamed from: a */
    public final float mo319a() {
        return ((float) this.f332a.mo251a()) / 2.0f;
    }

    /* renamed from: a */
    public final void mo320a(int i, int i2, int i3, int i4) {
        this.f332a.f259c.set(i, i2, i3, i4);
        this.f332a.setPadding(this.f332a.f257a + i, this.f332a.f257a + i2, this.f332a.f257a + i3, this.f332a.f257a + i4);
    }

    /* renamed from: a */
    public final void mo321a(Drawable drawable) {
        C0049as.super.setBackgroundDrawable(drawable);
    }

    /* renamed from: b */
    public final boolean mo322b() {
        return this.f332a.f258b;
    }
}
