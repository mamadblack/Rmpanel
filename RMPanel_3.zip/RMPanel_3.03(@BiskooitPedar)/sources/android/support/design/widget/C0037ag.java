package android.support.design.widget;

import android.support.p003v4.p014g.C0349ae;
import android.support.p003v4.p014g.C0397bv;
import android.view.View;

/* renamed from: android.support.design.widget.ag */
final class C0037ag implements C0349ae {

    /* renamed from: a */
    final /* synthetic */ CoordinatorLayout f304a;

    C0037ag(CoordinatorLayout coordinatorLayout) {
        this.f304a = coordinatorLayout;
    }

    /* renamed from: a */
    public final C0397bv mo295a(View view, C0397bv bvVar) {
        return this.f304a.mo212a(bvVar);
    }
}
