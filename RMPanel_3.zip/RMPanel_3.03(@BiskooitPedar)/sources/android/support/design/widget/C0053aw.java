package android.support.design.widget;

import android.view.ViewTreeObserver.OnPreDrawListener;

/* renamed from: android.support.design.widget.aw */
final class C0053aw implements OnPreDrawListener {

    /* renamed from: a */
    final /* synthetic */ C0050at f358a;

    C0053aw(C0050at atVar) {
        this.f358a = atVar;
    }

    public final boolean onPreDraw() {
        this.f358a.mo333f();
        return true;
    }
}
