package android.support.design.widget;

import android.view.ViewTreeObserver.OnPreDrawListener;

/* renamed from: android.support.design.widget.al */
final class C0042al implements OnPreDrawListener {

    /* renamed from: a */
    final /* synthetic */ CoordinatorLayout f323a;

    C0042al(CoordinatorLayout coordinatorLayout) {
        this.f323a = coordinatorLayout;
    }

    public final boolean onPreDraw() {
        this.f323a.mo213a(0);
        return true;
    }
}
