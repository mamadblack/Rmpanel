package android.support.design.widget;

import android.support.p003v4.p013f.C0295r;
import android.support.p003v4.p013f.C0296s;
import android.support.p003v4.p013f.C0298u;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/* renamed from: android.support.design.widget.ap */
final class C0046ap<T> {

    /* renamed from: a */
    private final C0295r<ArrayList<T>> f326a = new C0296s(10);

    /* renamed from: b */
    private final C0298u<T, ArrayList<T>> f327b = new C0298u<>();

    /* renamed from: c */
    private final ArrayList<T> f328c = new ArrayList<>();

    /* renamed from: d */
    private final HashSet<T> f329d = new HashSet<>();

    C0046ap() {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo312a(T t) {
        if (!this.f327b.containsKey(t)) {
            this.f327b.put(t, null);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final boolean mo315b(T t) {
        return this.f327b.containsKey(t);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo313a(T t, T t2) {
        if (!this.f327b.containsKey(t) || !this.f327b.containsKey(t2)) {
            throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
        }
        ArrayList arrayList = (ArrayList) this.f327b.get(t);
        if (arrayList == null) {
            arrayList = (ArrayList) this.f326a.mo918a();
            if (arrayList == null) {
                arrayList = new ArrayList();
            }
            this.f327b.put(t, arrayList);
        }
        arrayList.add(t2);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public final List mo316c(T t) {
        return (List) this.f327b.get(t);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final List mo317d(T t) {
        ArrayList arrayList;
        ArrayList arrayList2 = null;
        int size = this.f327b.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList3 = (ArrayList) this.f327b.mo924c(i);
            if (arrayList3 != null && arrayList3.contains(t)) {
                if (arrayList2 == null) {
                    arrayList = new ArrayList();
                } else {
                    arrayList = arrayList2;
                }
                arrayList.add(this.f327b.mo923b(i));
                arrayList2 = arrayList;
            }
        }
        return arrayList2;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public final boolean mo318e(T t) {
        int size = this.f327b.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.f327b.mo924c(i);
            if (arrayList != null && arrayList.contains(t)) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo311a() {
        int size = this.f327b.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.f327b.mo924c(i);
            if (arrayList != null) {
                arrayList.clear();
                this.f326a.mo919a(arrayList);
            }
        }
        this.f327b.clear();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final ArrayList<T> mo314b() {
        this.f328c.clear();
        this.f329d.clear();
        int size = this.f327b.size();
        for (int i = 0; i < size; i++) {
            m203a(this.f327b.mo923b(i), this.f328c, this.f329d);
        }
        return this.f328c;
    }

    /* renamed from: a */
    private void m203a(T t, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (!arrayList.contains(t)) {
            if (hashSet.contains(t)) {
                throw new RuntimeException("This graph contains cyclic dependencies");
            }
            hashSet.add(t);
            ArrayList arrayList2 = (ArrayList) this.f327b.get(t);
            if (arrayList2 != null) {
                int size = arrayList2.size();
                for (int i = 0; i < size; i++) {
                    m203a(arrayList2.get(i), arrayList, hashSet);
                }
            }
            hashSet.remove(t);
            arrayList.add(t);
        }
    }
}
