package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.support.design.C0029j;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

/* renamed from: android.support.design.widget.ak */
public final class C0041ak extends MarginLayoutParams {

    /* renamed from: a */
    C0038ah f306a;

    /* renamed from: b */
    boolean f307b = false;

    /* renamed from: c */
    public int f308c = 0;

    /* renamed from: d */
    public int f309d = 0;

    /* renamed from: e */
    public int f310e = -1;

    /* renamed from: f */
    int f311f = -1;

    /* renamed from: g */
    public int f312g = 0;

    /* renamed from: h */
    public int f313h = 0;

    /* renamed from: i */
    int f314i;

    /* renamed from: j */
    int f315j;

    /* renamed from: k */
    View f316k;

    /* renamed from: l */
    View f317l;

    /* renamed from: m */
    final Rect f318m = new Rect();

    /* renamed from: n */
    Object f319n;

    /* renamed from: o */
    private boolean f320o;

    /* renamed from: p */
    private boolean f321p;

    /* renamed from: q */
    private boolean f322q;

    public C0041ak() {
        super(-2, -2);
    }

    C0041ak(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0029j.f117F);
        this.f308c = obtainStyledAttributes.getInteger(C0029j.f118G, 0);
        this.f311f = obtainStyledAttributes.getResourceId(C0029j.f119H, -1);
        this.f309d = obtainStyledAttributes.getInteger(C0029j.f120I, 0);
        this.f310e = obtainStyledAttributes.getInteger(C0029j.f124M, -1);
        this.f312g = obtainStyledAttributes.getInt(C0029j.f123L, 0);
        this.f313h = obtainStyledAttributes.getInt(C0029j.f122K, 0);
        this.f307b = obtainStyledAttributes.hasValue(C0029j.f121J);
        if (this.f307b) {
            this.f306a = CoordinatorLayout.m113a(context, attributeSet, obtainStyledAttributes.getString(C0029j.f121J));
        }
        obtainStyledAttributes.recycle();
        if (this.f306a != null) {
            this.f306a.mo269a(this);
        }
    }

    public C0041ak(C0041ak akVar) {
        super(akVar);
    }

    public C0041ak(MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
    }

    public C0041ak(LayoutParams layoutParams) {
        super(layoutParams);
    }

    /* renamed from: a */
    public final void mo299a(C0038ah ahVar) {
        if (this.f306a != ahVar) {
            this.f306a = ahVar;
            this.f319n = null;
            this.f307b = true;
            if (ahVar != null) {
                ahVar.mo269a(this);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo301a() {
        if (this.f306a == null) {
            this.f320o = false;
        }
        return this.f320o;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final boolean mo303b() {
        if (this.f320o) {
            return true;
        }
        boolean z = this.f320o | false;
        this.f320o = z;
        return z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public final void mo304c() {
        this.f320o = false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final void mo305d() {
        this.f321p = false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo300a(boolean z) {
        this.f321p = z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public final boolean mo306e() {
        return this.f321p;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public final boolean mo307f() {
        return this.f322q;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final void mo302b(boolean z) {
        this.f322q = z;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public final void mo308g() {
        this.f322q = false;
    }
}
