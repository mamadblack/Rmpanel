package android.support.design.widget;

/* renamed from: android.support.design.widget.aq */
final class C0047aq implements C0056az {

    /* renamed from: a */
    final /* synthetic */ C0048ar f330a;

    /* renamed from: b */
    final /* synthetic */ FloatingActionButton f331b;

    C0047aq(FloatingActionButton floatingActionButton, C0048ar arVar) {
        this.f331b = floatingActionButton;
        this.f330a = arVar;
    }
}
