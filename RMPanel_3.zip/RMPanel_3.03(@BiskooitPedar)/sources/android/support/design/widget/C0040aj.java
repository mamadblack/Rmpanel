package android.support.design.widget;

import android.view.View;
import android.view.ViewGroup.OnHierarchyChangeListener;

/* renamed from: android.support.design.widget.aj */
final class C0040aj implements OnHierarchyChangeListener {

    /* renamed from: a */
    final /* synthetic */ CoordinatorLayout f305a;

    C0040aj(CoordinatorLayout coordinatorLayout) {
        this.f305a = coordinatorLayout;
    }

    public final void onChildViewAdded(View view, View view2) {
        if (this.f305a.f238e != null) {
            this.f305a.f238e.onChildViewAdded(view, view2);
        }
    }

    public final void onChildViewRemoved(View view, View view2) {
        this.f305a.mo213a(2);
        if (this.f305a.f238e != null) {
            this.f305a.f238e.onChildViewRemoved(view, view2);
        }
    }
}
