package android.support.design.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.support.design.C0020c;
import android.support.design.C0026i;
import android.support.design.C0029j;
import android.support.p003v4.p014g.C0349ae;
import android.support.p003v4.p014g.C0351ag;
import android.support.p003v4.p014g.C0397bv;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import java.lang.ref.WeakReference;
import java.util.List;

@C0039ai(mo296a = Behavior.class)
public class AppBarLayout extends LinearLayout {

    /* renamed from: a */
    private int f191a;

    /* renamed from: b */
    private int f192b;

    /* renamed from: c */
    private int f193c;

    /* renamed from: d */
    private boolean f194d;

    /* renamed from: e */
    private int f195e;

    /* renamed from: f */
    private C0397bv f196f;

    /* renamed from: g */
    private List<Object> f197g;

    /* renamed from: h */
    private boolean f198h;

    /* renamed from: i */
    private boolean f199i;

    /* renamed from: j */
    private final int[] f200j;

    public class Behavior extends C0061bd<AppBarLayout> {
        /* access modifiers changed from: private */

        /* renamed from: b */
        public int f201b;

        /* renamed from: c */
        private boolean f202c;

        /* renamed from: d */
        private boolean f203d;

        /* renamed from: e */
        private ValueAnimator f204e;

        /* renamed from: f */
        private int f205f = -1;

        /* renamed from: g */
        private boolean f206g;

        /* renamed from: h */
        private float f207h;

        /* renamed from: i */
        private WeakReference<View> f208i;

        /* renamed from: j */
        private C0085d f209j;

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public final /* synthetic */ int mo179a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3) {
            int i4;
            int i5;
            int i6;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            int a = mo178a();
            if (i2 == 0 || a < i2 || a > i3) {
                this.f201b = 0;
                return 0;
            }
            int a2 = C0064bg.m260a(i, i2, i3);
            if (a == a2) {
                return 0;
            }
            if (appBarLayout.mo158a()) {
                int abs = Math.abs(a2);
                int childCount = appBarLayout.getChildCount();
                int i7 = 0;
                while (true) {
                    if (i7 >= childCount) {
                        break;
                    }
                    View childAt = appBarLayout.getChildAt(i7);
                    C0088g gVar = (C0088g) childAt.getLayoutParams();
                    Interpolator interpolator = gVar.f442b;
                    if (abs < childAt.getTop() || abs > childAt.getBottom()) {
                        i7++;
                    } else if (interpolator != null) {
                        int i8 = gVar.f441a;
                        if ((i8 & 1) != 0) {
                            i6 = gVar.bottomMargin + childAt.getHeight() + gVar.topMargin + 0;
                            if ((i8 & 2) != 0) {
                                i6 -= C0351ag.m1183j(childAt);
                            }
                        } else {
                            i6 = 0;
                        }
                        if (C0351ag.m1188o(childAt)) {
                            i6 -= appBarLayout.mo173k();
                        }
                        if (i6 > 0) {
                            int top = abs - childAt.getTop();
                            int round = Math.round(interpolator.getInterpolation(((float) top) / ((float) i6)) * ((float) i6));
                            i4 = (round + childAt.getTop()) * Integer.signum(a2);
                        }
                    }
                }
                i4 = a2;
            } else {
                i4 = a2;
            }
            boolean a3 = super.mo185a(i4);
            int i9 = a - a2;
            this.f201b = a2 - i4;
            if (!a3 && appBarLayout.mo158a()) {
                coordinatorLayout.mo214a((View) appBarLayout);
            }
            appBarLayout.mo166g();
            if (a2 < a) {
                i5 = -1;
            } else {
                i5 = 1;
            }
            m68a(coordinatorLayout, appBarLayout, a2, i5, false);
            return i9;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public final /* synthetic */ int mo180a(View view) {
            return ((AppBarLayout) view).mo159b();
        }

        /* renamed from: a */
        public final /* bridge */ /* synthetic */ void mo182a(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (parcelable instanceof C0086e) {
                C0086e eVar = (C0086e) parcelable;
                super.mo182a(coordinatorLayout, appBarLayout, eVar.mo946a());
                this.f205f = eVar.f438a;
                this.f207h = eVar.f439b;
                this.f206g = eVar.f440c;
                return;
            }
            super.mo182a(coordinatorLayout, appBarLayout, parcelable);
            this.f205f = -1;
        }

        /* renamed from: a */
        public final /* synthetic */ void mo183a(CoordinatorLayout coordinatorLayout, View view, View view2) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (!this.f203d) {
                mo181a(coordinatorLayout, appBarLayout);
            }
            this.f202c = false;
            this.f203d = false;
            this.f208i = new WeakReference<>(view2);
        }

        /* renamed from: a */
        public final /* synthetic */ void mo184a(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int[] iArr) {
            int i2;
            int i3;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (i != 0 && !this.f202c) {
                if (i < 0) {
                    i2 = -appBarLayout.mo159b();
                    i3 = i2 + appBarLayout.mo164e();
                } else {
                    i2 = -appBarLayout.mo163d();
                    i3 = 0;
                }
                iArr[1] = mo345b(coordinatorLayout, appBarLayout, i, i2, i3);
            }
        }

        /* renamed from: a */
        public final /* bridge */ /* synthetic */ boolean mo185a(int i) {
            return super.mo185a(i);
        }

        /* renamed from: a */
        public final /* synthetic */ boolean mo186a(CoordinatorLayout coordinatorLayout, View view, float f, boolean z) {
            boolean z2 = true;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (!z) {
                z2 = mo343a(coordinatorLayout, appBarLayout, -appBarLayout.mo159b(), -f);
            } else {
                if (f < 0.0f) {
                    int e = (-appBarLayout.mo159b()) + appBarLayout.mo164e();
                    if (mo178a() < e) {
                        m67a(coordinatorLayout, appBarLayout, e, f);
                    }
                } else {
                    int i = -appBarLayout.mo163d();
                    if (mo178a() > i) {
                        m67a(coordinatorLayout, appBarLayout, i, f);
                    }
                }
                z2 = false;
            }
            this.f203d = z2;
            return z2;
        }

        /* renamed from: a */
        public final /* synthetic */ boolean mo187a(CoordinatorLayout coordinatorLayout, View view, int i) {
            boolean z;
            int round;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            boolean a = super.mo187a(coordinatorLayout, appBarLayout, i);
            int i2 = appBarLayout.mo171i();
            if (this.f205f >= 0 && (i2 & 8) == 0) {
                View childAt = appBarLayout.getChildAt(this.f205f);
                int i3 = -childAt.getBottom();
                if (this.f206g) {
                    round = C0351ag.m1183j(childAt) + appBarLayout.mo173k() + i3;
                } else {
                    round = Math.round(((float) childAt.getHeight()) * this.f207h) + i3;
                }
                mo344a_(coordinatorLayout, appBarLayout, round);
            } else if (i2 != 0) {
                if ((i2 & 4) != 0) {
                    z = true;
                } else {
                    z = false;
                }
                if ((i2 & 2) != 0) {
                    int i4 = -appBarLayout.mo163d();
                    if (z) {
                        m67a(coordinatorLayout, appBarLayout, i4, 0.0f);
                    } else {
                        mo344a_(coordinatorLayout, appBarLayout, i4);
                    }
                } else if ((i2 & 1) != 0) {
                    if (z) {
                        m67a(coordinatorLayout, appBarLayout, 0, 0.0f);
                    } else {
                        mo344a_(coordinatorLayout, appBarLayout, 0);
                    }
                }
            }
            appBarLayout.mo172j();
            this.f205f = -1;
            super.mo185a(C0064bg.m260a(super.mo194c(), -appBarLayout.mo159b(), 0));
            m68a(coordinatorLayout, appBarLayout, super.mo194c(), 0, true);
            appBarLayout.mo166g();
            return a;
        }

        /* renamed from: a */
        public final /* synthetic */ boolean mo188a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (((C0041ak) appBarLayout.getLayoutParams()).height != -2) {
                return super.mo188a(coordinatorLayout, appBarLayout, i, i2, i3, i4);
            }
            coordinatorLayout.mo216a(appBarLayout, i, i2, MeasureSpec.makeMeasureSpec(0, 0), i4);
            return true;
        }

        /* renamed from: a */
        public final /* synthetic */ boolean mo189a(CoordinatorLayout coordinatorLayout, View view, View view2, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            boolean z = (i & 2) != 0 && appBarLayout.mo161c() && coordinatorLayout.getHeight() - view2.getHeight() <= appBarLayout.getHeight();
            if (z && this.f204e != null) {
                this.f204e.cancel();
            }
            this.f208i = null;
            return z;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public final /* synthetic */ int mo190b(View view) {
            return -((AppBarLayout) view).mo165f();
        }

        /* renamed from: b */
        public final /* synthetic */ Parcelable mo191b(CoordinatorLayout coordinatorLayout, View view) {
            boolean z = false;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            Parcelable b = super.mo191b(coordinatorLayout, appBarLayout);
            int c = super.mo194c();
            int childCount = appBarLayout.getChildCount();
            int i = 0;
            while (i < childCount) {
                View childAt = appBarLayout.getChildAt(i);
                int bottom = childAt.getBottom() + c;
                if (childAt.getTop() + c > 0 || bottom < 0) {
                    i++;
                } else {
                    C0086e eVar = new C0086e(b);
                    eVar.f438a = i;
                    if (bottom == C0351ag.m1183j(childAt) + appBarLayout.mo173k()) {
                        z = true;
                    }
                    eVar.f440c = z;
                    eVar.f439b = ((float) bottom) / ((float) childAt.getHeight());
                    return eVar;
                }
            }
            return b;
        }

        /* renamed from: b */
        public final /* synthetic */ void mo192b(CoordinatorLayout coordinatorLayout, View view, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (i < 0) {
                mo345b(coordinatorLayout, appBarLayout, i, -appBarLayout.mo165f(), 0);
                this.f202c = true;
                return;
            }
            this.f202c = false;
        }

        /* renamed from: c */
        public final /* bridge */ /* synthetic */ int mo194c() {
            return super.mo194c();
        }

        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        /* renamed from: a */
        private void m67a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, float f) {
            int height;
            int abs = Math.abs(mo178a() - i);
            float abs2 = Math.abs(f);
            if (abs2 > 0.0f) {
                height = Math.round((((float) abs) / abs2) * 1000.0f) * 3;
            } else {
                height = (int) (((((float) abs) / ((float) appBarLayout.getHeight())) + 1.0f) * 150.0f);
            }
            int a = mo178a();
            if (a != i) {
                if (this.f204e == null) {
                    this.f204e = new ValueAnimator();
                    this.f204e.setInterpolator(C0030a.f284e);
                    this.f204e.addUpdateListener(new C0084c(this, coordinatorLayout, appBarLayout));
                } else {
                    this.f204e.cancel();
                }
                this.f204e.setDuration((long) Math.min(height, 600));
                this.f204e.setIntValues(new int[]{a, i});
                this.f204e.start();
            } else if (this.f204e != null && this.f204e.isRunning()) {
                this.f204e.cancel();
            }
        }

        /* access modifiers changed from: private */
        /* renamed from: a */
        public void mo181a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            int i;
            int i2;
            int a = mo178a();
            int childCount = appBarLayout.getChildCount();
            int i3 = 0;
            while (true) {
                if (i3 >= childCount) {
                    i = -1;
                    break;
                }
                View childAt = appBarLayout.getChildAt(i3);
                if (childAt.getTop() <= (-a) && childAt.getBottom() >= (-a)) {
                    i = i3;
                    break;
                }
                i3++;
            }
            if (i >= 0) {
                View childAt2 = appBarLayout.getChildAt(i);
                int i4 = ((C0088g) childAt2.getLayoutParams()).f441a;
                if ((i4 & 17) == 17) {
                    int i5 = -childAt2.getTop();
                    int i6 = -childAt2.getBottom();
                    if (i == appBarLayout.getChildCount() - 1) {
                        i6 += appBarLayout.mo173k();
                    }
                    if (m69a(i4, 2)) {
                        i6 += C0351ag.m1183j(childAt2);
                        i2 = i5;
                    } else if (m69a(i4, 5)) {
                        i2 = C0351ag.m1183j(childAt2) + i6;
                        if (a >= i2) {
                            i6 = i2;
                            i2 = i5;
                        }
                    } else {
                        i2 = i5;
                    }
                    if (a >= (i6 + i2) / 2) {
                        i6 = i2;
                    }
                    m67a(coordinatorLayout, appBarLayout, C0064bg.m260a(i6, -appBarLayout.mo159b(), 0), 0.0f);
                }
            }
        }

        /* renamed from: a */
        private static boolean m69a(int i, int i2) {
            return (i & i2) == i2;
        }

        /* JADX WARNING: Removed duplicated region for block: B:19:0x004e  */
        /* JADX WARNING: Removed duplicated region for block: B:49:? A[RETURN, SYNTHETIC] */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private static void m68a(android.support.design.widget.CoordinatorLayout r7, android.support.design.widget.AppBarLayout r8, int r9, int r10, boolean r11) {
            /*
                r1 = 1
                r2 = 0
                int r4 = java.lang.Math.abs(r9)
                int r5 = r8.getChildCount()
                r3 = r2
            L_0x000b:
                if (r3 >= r5) goto L_0x0082
                android.view.View r0 = r8.getChildAt(r3)
                int r6 = r0.getTop()
                if (r4 < r6) goto L_0x007e
                int r6 = r0.getBottom()
                if (r4 > r6) goto L_0x007e
                r3 = r0
            L_0x001e:
                if (r3 == 0) goto L_0x007d
                android.view.ViewGroup$LayoutParams r0 = r3.getLayoutParams()
                android.support.design.widget.g r0 = (android.support.design.widget.C0088g) r0
                int r0 = r0.f441a
                r4 = r0 & 1
                if (r4 == 0) goto L_0x00a0
                int r4 = android.support.p003v4.p014g.C0351ag.m1183j(r3)
                if (r10 <= 0) goto L_0x0087
                r5 = r0 & 12
                if (r5 == 0) goto L_0x0087
                int r0 = -r9
                int r3 = r3.getBottom()
                int r3 = r3 - r4
                int r4 = r8.mo173k()
                int r3 = r3 - r4
                if (r0 < r3) goto L_0x0085
                r0 = r1
            L_0x0044:
                boolean r0 = r8.mo160b(r0)
                int r3 = android.os.Build.VERSION.SDK_INT
                r4 = 11
                if (r3 < r4) goto L_0x007d
                if (r11 != 0) goto L_0x007a
                if (r0 == 0) goto L_0x007d
                java.util.List r4 = r7.mo219c(r8)
                int r5 = r4.size()
                r3 = r2
            L_0x005b:
                if (r3 >= r5) goto L_0x0078
                java.lang.Object r0 = r4.get(r3)
                android.view.View r0 = (android.view.View) r0
                android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
                android.support.design.widget.ak r0 = (android.support.design.widget.C0041ak) r0
                android.support.design.widget.ah r0 = r0.f306a
                boolean r6 = r0 instanceof android.support.design.widget.AppBarLayout.ScrollingViewBehavior
                if (r6 == 0) goto L_0x009c
                android.support.design.widget.AppBarLayout$ScrollingViewBehavior r0 = (android.support.design.widget.AppBarLayout.ScrollingViewBehavior) r0
                int r0 = r0.mo348b()
                if (r0 == 0) goto L_0x0078
                r2 = r1
            L_0x0078:
                if (r2 == 0) goto L_0x007d
            L_0x007a:
                r8.jumpDrawablesToCurrentState()
            L_0x007d:
                return
            L_0x007e:
                int r0 = r3 + 1
                r3 = r0
                goto L_0x000b
            L_0x0082:
                r0 = 0
                r3 = r0
                goto L_0x001e
            L_0x0085:
                r0 = r2
                goto L_0x0044
            L_0x0087:
                r0 = r0 & 2
                if (r0 == 0) goto L_0x00a0
                int r0 = -r9
                int r3 = r3.getBottom()
                int r3 = r3 - r4
                int r4 = r8.mo173k()
                int r3 = r3 - r4
                if (r0 < r3) goto L_0x009a
                r0 = r1
                goto L_0x0044
            L_0x009a:
                r0 = r2
                goto L_0x0044
            L_0x009c:
                int r0 = r3 + 1
                r3 = r0
                goto L_0x005b
            L_0x00a0:
                r0 = r2
                goto L_0x0044
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.design.widget.AppBarLayout.Behavior.m68a(android.support.design.widget.CoordinatorLayout, android.support.design.widget.AppBarLayout, int, int, boolean):void");
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public final int mo178a() {
            return super.mo194c() + this.f201b;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public final /* synthetic */ boolean mo193b() {
            if (this.f209j != null) {
                return this.f209j.mo386a();
            }
            if (this.f208i != null) {
                View view = (View) this.f208i.get();
                if (view == null || !view.isShown() || C0351ag.m1170a(view, -1)) {
                    return false;
                }
            }
            return true;
        }
    }

    public class ScrollingViewBehavior extends C0063bf {
        /* access modifiers changed from: 0000 */
        /* renamed from: a */
        public final /* synthetic */ View mo195a(List list) {
            return m87b(list);
        }

        /* renamed from: a */
        public final /* bridge */ /* synthetic */ boolean mo185a(int i) {
            return super.mo185a(i);
        }

        /* renamed from: a */
        public final /* bridge */ /* synthetic */ boolean mo187a(CoordinatorLayout coordinatorLayout, View view, int i) {
            return super.mo187a(coordinatorLayout, view, i);
        }

        /* renamed from: a */
        public final /* bridge */ /* synthetic */ boolean mo188a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            return super.mo188a(coordinatorLayout, view, i, i2, i3, i4);
        }

        /* renamed from: c */
        public final /* bridge */ /* synthetic */ int mo194c() {
            return super.mo194c();
        }

        public ScrollingViewBehavior() {
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0029j.f150ak);
            mo349b(obtainStyledAttributes.getDimensionPixelSize(C0029j.f151al, 0));
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a_ */
        public final boolean mo197a_(View view) {
            return view instanceof AppBarLayout;
        }

        /* renamed from: a */
        public final boolean mo196a(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z) {
            boolean z2 = false;
            AppBarLayout b = m87b(coordinatorLayout.mo218b(view));
            if (b != null) {
                rect.offset(view.getLeft(), view.getTop());
                Rect rect2 = this.f378a;
                rect2.set(0, 0, coordinatorLayout.getWidth(), coordinatorLayout.getHeight());
                if (!rect2.contains(rect)) {
                    if (!z) {
                        z2 = true;
                    }
                    b.mo157a(z2);
                    return true;
                }
            }
            return false;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: b */
        public final float mo198b(View view) {
            int i;
            if (view instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view;
                int b = appBarLayout.mo159b();
                int e = appBarLayout.mo164e();
                C0038ah ahVar = ((C0041ak) appBarLayout.getLayoutParams()).f306a;
                if (ahVar instanceof Behavior) {
                    i = ((Behavior) ahVar).mo178a();
                } else {
                    i = 0;
                }
                if (e != 0 && b + i <= e) {
                    return 0.0f;
                }
                int i2 = b - e;
                if (i2 != 0) {
                    return (((float) i) / ((float) i2)) + 1.0f;
                }
            }
            return 0.0f;
        }

        /* renamed from: b */
        private static AppBarLayout m87b(List<View> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                View view = (View) list.get(i);
                if (view instanceof AppBarLayout) {
                    return (AppBarLayout) view;
                }
            }
            return null;
        }

        /* access modifiers changed from: 0000 */
        /* renamed from: c */
        public final int mo200c(View view) {
            if (view instanceof AppBarLayout) {
                return ((AppBarLayout) view).mo159b();
            }
            return super.mo200c(view);
        }

        /* renamed from: b */
        public final boolean mo199b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            C0038ah ahVar = ((C0041ak) view2.getLayoutParams()).f306a;
            if (ahVar instanceof Behavior) {
                int bottom = view2.getBottom() - view.getTop();
                C0351ag.m1174c(view, ((((Behavior) ahVar).f201b + bottom) + mo347a()) - mo351d(view2));
            }
            return false;
        }
    }

    public AppBarLayout(Context context) {
        this(context, null);
    }

    public AppBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f191a = -1;
        this.f192b = -1;
        this.f193c = -1;
        this.f195e = 0;
        this.f200j = new int[2];
        setOrientation(1);
        C0077bt.m299a(context);
        if (VERSION.SDK_INT >= 21) {
            C0082by.m312a(this);
            C0082by.m314a(this, attributeSet, C0026i.Widget_Design_AppBarLayout);
        }
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0029j.f172h, 0, C0026i.Widget_Design_AppBarLayout);
        C0351ag.m1162a((View) this, obtainStyledAttributes.getDrawable(C0029j.f177m));
        if (obtainStyledAttributes.hasValue(C0029j.f179o)) {
            m49a(obtainStyledAttributes.getBoolean(C0029j.f179o, false), false, false);
        }
        if (VERSION.SDK_INT >= 21 && obtainStyledAttributes.hasValue(C0029j.f178n)) {
            C0082by.m313a(this, (float) obtainStyledAttributes.getDimensionPixelSize(C0029j.f178n, 0));
        }
        obtainStyledAttributes.recycle();
        C0351ag.m1163a((View) this, (C0349ae) new C0057b(this));
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        m50l();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2;
        boolean z3;
        super.onLayout(z, i, i2, i3, i4);
        m50l();
        this.f194d = false;
        int childCount = getChildCount();
        int i5 = 0;
        while (true) {
            if (i5 >= childCount) {
                break;
            } else if (((C0088g) getChildAt(i5).getLayoutParams()).f442b != null) {
                this.f194d = true;
                break;
            } else {
                i5++;
            }
        }
        int childCount2 = getChildCount();
        int i6 = 0;
        while (true) {
            if (i6 >= childCount2) {
                z2 = false;
                break;
            }
            C0088g gVar = (C0088g) getChildAt(i6).getLayoutParams();
            if ((gVar.f441a & 1) != 1 || (gVar.f441a & 10) == 0) {
                z3 = false;
            } else {
                z3 = true;
            }
            if (z3) {
                z2 = true;
                break;
            }
            i6++;
        }
        if (this.f198h != z2) {
            this.f198h = z2;
            refreshDrawableState();
        }
    }

    /* renamed from: l */
    private void m50l() {
        this.f191a = -1;
        this.f192b = -1;
        this.f193c = -1;
    }

    public void setOrientation(int i) {
        if (i != 1) {
            throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
        }
        super.setOrientation(i);
    }

    /* renamed from: a */
    public final void mo157a(boolean z) {
        m49a(false, z, true);
    }

    /* renamed from: a */
    private void m49a(boolean z, boolean z2, boolean z3) {
        int i = 0;
        int i2 = (z2 ? 4 : 0) | (z ? 1 : 2);
        if (z3) {
            i = 8;
        }
        this.f195e = i | i2;
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0088g;
    }

    /* access modifiers changed from: private */
    /* renamed from: a */
    public C0088g generateLayoutParams(AttributeSet attributeSet) {
        return new C0088g(getContext(), attributeSet);
    }

    /* renamed from: a */
    private static C0088g m48a(LayoutParams layoutParams) {
        if (VERSION.SDK_INT >= 19 && (layoutParams instanceof LinearLayout.LayoutParams)) {
            return new C0088g((LinearLayout.LayoutParams) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new C0088g((MarginLayoutParams) layoutParams);
        }
        return new C0088g(layoutParams);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo158a() {
        return this.f194d;
    }

    /* renamed from: b */
    public final int mo159b() {
        int i;
        if (this.f191a != -1) {
            return this.f191a;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            C0088g gVar = (C0088g) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = gVar.f441a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += gVar.bottomMargin + measuredHeight + gVar.topMargin;
            if ((i4 & 2) != 0) {
                i = i3 - C0351ag.m1183j(childAt);
                break;
            }
            i2++;
        }
        i = i3;
        int max = Math.max(0, i - mo173k());
        this.f191a = max;
        return max;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public final boolean mo161c() {
        return mo159b() != 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final int mo163d() {
        return mo159b();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public final int mo164e() {
        int i;
        if (this.f192b != -1) {
            return this.f192b;
        }
        int childCount = getChildCount() - 1;
        int i2 = 0;
        while (childCount >= 0) {
            View childAt = getChildAt(childCount);
            C0088g gVar = (C0088g) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = gVar.f441a;
            if ((i3 & 5) != 5) {
                if (i2 > 0) {
                    break;
                }
                i = i2;
            } else {
                int i4 = gVar.bottomMargin + gVar.topMargin + i2;
                if ((i3 & 8) != 0) {
                    i = i4 + C0351ag.m1183j(childAt);
                } else if ((i3 & 2) != 0) {
                    i = i4 + (measuredHeight - C0351ag.m1183j(childAt));
                } else {
                    i = i4 + (measuredHeight - mo173k());
                }
            }
            childCount--;
            i2 = i;
        }
        int max = Math.max(0, i2);
        this.f192b = max;
        return max;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public final int mo165f() {
        int i;
        if (this.f193c != -1) {
            return this.f193c;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            C0088g gVar = (C0088g) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + gVar.topMargin + gVar.bottomMargin;
            int i4 = gVar.f441a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += measuredHeight;
            if ((i4 & 2) != 0) {
                i = i3 - (C0351ag.m1183j(childAt) + mo173k());
                break;
            }
            i2++;
        }
        i = i3;
        int max = Math.max(0, i);
        this.f193c = max;
        return max;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: g */
    public final void mo166g() {
        if (this.f197g != null) {
            int size = this.f197g.size();
            for (int i = 0; i < size; i++) {
                this.f197g.get(i);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: h */
    public final int mo170h() {
        int k = mo173k();
        int j = C0351ag.m1183j(this);
        if (j != 0) {
            return (j * 2) + k;
        }
        int childCount = getChildCount();
        int i = childCount > 0 ? C0351ag.m1183j(getChildAt(childCount - 1)) : 0;
        if (i != 0) {
            return (i * 2) + k;
        }
        return getHeight() / 3;
    }

    /* access modifiers changed from: protected */
    public int[] onCreateDrawableState(int i) {
        int[] iArr = this.f200j;
        int[] onCreateDrawableState = super.onCreateDrawableState(iArr.length + i);
        iArr[0] = this.f198h ? C0020c.state_collapsible : -C0020c.state_collapsible;
        iArr[1] = (!this.f198h || !this.f199i) ? -C0020c.state_collapsed : C0020c.state_collapsed;
        return mergeDrawableStates(onCreateDrawableState, iArr);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final boolean mo160b(boolean z) {
        if (this.f199i == z) {
            return false;
        }
        this.f199i = z;
        refreshDrawableState();
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: i */
    public final int mo171i() {
        return this.f195e;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: j */
    public final void mo172j() {
        this.f195e = 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: k */
    public final int mo173k() {
        if (this.f196f != null) {
            return this.f196f.mo1119b();
        }
        return 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final C0397bv mo156a(C0397bv bvVar) {
        C0397bv bvVar2 = null;
        if (C0351ag.m1188o(this)) {
            bvVar2 = bvVar;
        }
        if (!C0081bx.m311a(this.f196f, bvVar2)) {
            this.f196f = bvVar2;
            m50l();
        }
        return bvVar;
    }
}
