package android.support.design.widget;

import android.animation.ValueAnimator;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.p003v4.p014g.C0351ag;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.Interpolator;

/* renamed from: android.support.design.widget.at */
class C0050at {

    /* renamed from: a */
    static final Interpolator f333a = C0030a.f282c;

    /* renamed from: i */
    static final int[] f334i = {16842919, 16842910};

    /* renamed from: j */
    static final int[] f335j = {16842908, 16842910};

    /* renamed from: k */
    static final int[] f336k = {16842910};

    /* renamed from: l */
    static final int[] f337l = new int[0];

    /* renamed from: b */
    int f338b = 0;

    /* renamed from: c */
    C0065bh f339c;

    /* renamed from: d */
    Drawable f340d;

    /* renamed from: e */
    Drawable f341e;

    /* renamed from: f */
    C0036af f342f;

    /* renamed from: g */
    float f343g;

    /* renamed from: h */
    float f344h;

    /* renamed from: m */
    final C0083bz f345m;

    /* renamed from: n */
    final C0066bi f346n;

    /* renamed from: o */
    private final C0071bn f347o;

    /* renamed from: p */
    private float f348p;

    /* renamed from: q */
    private final Rect f349q = new Rect();

    /* renamed from: r */
    private OnPreDrawListener f350r;

    C0050at(C0083bz bzVar, C0066bi biVar) {
        this.f345m = bzVar;
        this.f346n = biVar;
        this.f347o = new C0071bn();
        this.f347o.mo372a(f334i, m216a((C0059bb) new C0055ay(this)));
        this.f347o.mo372a(f335j, m216a((C0059bb) new C0055ay(this)));
        this.f347o.mo372a(f336k, m216a((C0059bb) new C0058ba(this)));
        this.f347o.mo372a(f337l, m216a((C0059bb) new C0054ax(this)));
        this.f348p = this.f345m.getRotation();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo326a(int[] iArr) {
        this.f347o.mo371a(iArr);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo323a() {
        C0071bn bnVar = this.f347o;
        if (bnVar.f408a != null) {
            bnVar.f408a.end();
            bnVar.f408a = null;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo325a(C0056az azVar) {
        boolean z = this.f345m.getVisibility() == 0 ? this.f338b == 1 : this.f338b != 2;
        if (!z) {
            this.f345m.animate().cancel();
            if (m217g()) {
                this.f338b = 1;
                this.f345m.animate().scaleX(0.0f).scaleY(0.0f).alpha(0.0f).setDuration(200).setInterpolator(C0030a.f282c).setListener(new C0051au(this, azVar));
                return;
            }
            this.f345m.mo383a(4, false);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final void mo329b(C0056az azVar) {
        boolean z = true;
        if (this.f345m.getVisibility() != 0) {
            if (this.f338b != 2) {
                z = false;
            }
        } else if (this.f338b == 1) {
            z = false;
        }
        if (!z) {
            this.f345m.animate().cancel();
            if (m217g()) {
                this.f338b = 2;
                if (this.f345m.getVisibility() != 0) {
                    this.f345m.setAlpha(0.0f);
                    this.f345m.setScaleY(0.0f);
                    this.f345m.setScaleX(0.0f);
                }
                this.f345m.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(200).setInterpolator(C0030a.f283d).setListener(new C0052av(this, azVar));
                return;
            }
            this.f345m.mo383a(0, false);
            this.f345m.setAlpha(1.0f);
            this.f345m.setScaleY(1.0f);
            this.f345m.setScaleX(1.0f);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final void mo327b() {
        Rect rect = this.f349q;
        mo324a(rect);
        mo328b(rect);
        this.f346n.mo320a(rect.left, rect.top, rect.right, rect.bottom);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo324a(Rect rect) {
        this.f339c.getPadding(rect);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo328b(Rect rect) {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public final void mo330c() {
        if (mo332e()) {
            if (this.f350r == null) {
                this.f350r = new C0053aw(this);
            }
            this.f345m.getViewTreeObserver().addOnPreDrawListener(this.f350r);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: d */
    public final void mo331d() {
        if (this.f350r != null) {
            this.f345m.getViewTreeObserver().removeOnPreDrawListener(this.f350r);
            this.f350r = null;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public boolean mo332e() {
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public final void mo333f() {
        float rotation = this.f345m.getRotation();
        if (this.f348p != rotation) {
            this.f348p = rotation;
            if (VERSION.SDK_INT == 19) {
                if (this.f348p % 90.0f != 0.0f) {
                    if (this.f345m.getLayerType() != 1) {
                        this.f345m.setLayerType(1, null);
                    }
                } else if (this.f345m.getLayerType() != 0) {
                    this.f345m.setLayerType(0, null);
                }
            }
            if (this.f339c != null) {
                this.f339c.mo352a(-this.f348p);
            }
            if (this.f342f != null) {
                this.f342f.mo285a(-this.f348p);
            }
        }
    }

    /* renamed from: a */
    private static ValueAnimator m216a(C0059bb bbVar) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setInterpolator(f333a);
        valueAnimator.setDuration(100);
        valueAnimator.addListener(bbVar);
        valueAnimator.addUpdateListener(bbVar);
        valueAnimator.setFloatValues(new float[]{0.0f, 1.0f});
        return valueAnimator;
    }

    /* renamed from: g */
    private boolean m217g() {
        return C0351ag.m1196w(this.f345m) && !this.f345m.isInEditMode();
    }
}
