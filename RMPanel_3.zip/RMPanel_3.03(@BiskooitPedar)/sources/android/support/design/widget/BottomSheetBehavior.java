package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcelable;
import android.support.design.C0021d;
import android.support.design.C0029j;
import android.support.p003v4.p014g.C0351ag;
import android.support.p003v4.widget.C0454av;
import android.support.p003v4.widget.C0457ay;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;

public class BottomSheetBehavior<V extends View> extends C0038ah<V> {

    /* renamed from: a */
    int f210a;

    /* renamed from: b */
    int f211b;

    /* renamed from: c */
    boolean f212c;

    /* renamed from: d */
    int f213d = 4;

    /* renamed from: e */
    C0454av f214e;

    /* renamed from: f */
    int f215f;

    /* renamed from: g */
    WeakReference<V> f216g;

    /* renamed from: h */
    WeakReference<View> f217h;

    /* renamed from: i */
    int f218i;

    /* renamed from: j */
    boolean f219j;

    /* renamed from: k */
    private float f220k;

    /* renamed from: l */
    private int f221l;

    /* renamed from: m */
    private boolean f222m;

    /* renamed from: n */
    private int f223n;

    /* renamed from: o */
    private boolean f224o;

    /* renamed from: p */
    private boolean f225p;

    /* renamed from: q */
    private int f226q;

    /* renamed from: r */
    private boolean f227r;

    /* renamed from: s */
    private VelocityTracker f228s;

    /* renamed from: t */
    private int f229t;

    /* renamed from: u */
    private final C0457ay f230u = new C0031aa(this);

    public BottomSheetBehavior() {
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0029j.f186v);
        TypedValue peekValue = obtainStyledAttributes.peekValue(C0029j.f188x);
        if (peekValue == null || peekValue.data != -1) {
            m100b(obtainStyledAttributes.getDimensionPixelSize(C0029j.f188x, -1));
        } else {
            m100b(peekValue.data);
        }
        this.f212c = obtainStyledAttributes.getBoolean(C0029j.f187w, false);
        this.f224o = obtainStyledAttributes.getBoolean(C0029j.f189y, false);
        obtainStyledAttributes.recycle();
        this.f220k = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    /* renamed from: b */
    public final Parcelable mo191b(CoordinatorLayout coordinatorLayout, V v) {
        return new C0032ab(super.mo191b(coordinatorLayout, v), this.f213d);
    }

    /* renamed from: a */
    public final void mo182a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        C0032ab abVar = (C0032ab) parcelable;
        super.mo182a(coordinatorLayout, v, abVar.mo946a());
        if (abVar.f287a == 1 || abVar.f287a == 2) {
            this.f213d = 4;
        } else {
            this.f213d = abVar.f287a;
        }
    }

    /* renamed from: a */
    public final boolean mo187a(CoordinatorLayout coordinatorLayout, V v, int i) {
        int i2;
        if (C0351ag.m1188o(coordinatorLayout) && !C0351ag.m1188o(v)) {
            C0351ag.m1189p(v);
        }
        int top = v.getTop();
        coordinatorLayout.mo215a((View) v, i);
        this.f215f = coordinatorLayout.getHeight();
        if (this.f222m) {
            if (this.f223n == 0) {
                this.f223n = coordinatorLayout.getResources().getDimensionPixelSize(C0021d.design_bottom_sheet_peek_height_min);
            }
            i2 = Math.max(this.f223n, this.f215f - ((coordinatorLayout.getWidth() * 9) / 16));
        } else {
            i2 = this.f221l;
        }
        this.f210a = Math.max(0, this.f215f - v.getHeight());
        this.f211b = Math.max(this.f215f - i2, this.f210a);
        if (this.f213d == 3) {
            C0351ag.m1174c(v, this.f210a);
        } else if (this.f212c && this.f213d == 5) {
            C0351ag.m1174c(v, this.f215f);
        } else if (this.f213d == 4) {
            C0351ag.m1174c(v, this.f211b);
        } else if (this.f213d == 1 || this.f213d == 2) {
            C0351ag.m1174c(v, top - v.getTop());
        }
        if (this.f214e == null) {
            this.f214e = C0454av.m1501a((ViewGroup) coordinatorLayout, this.f230u);
        }
        this.f216g = new WeakReference<>(v);
        this.f217h = new WeakReference<>(m98b((View) v));
        return true;
    }

    /* renamed from: a */
    public final boolean mo203a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            this.f225p = true;
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            m99b();
        }
        if (this.f228s == null) {
            this.f228s = VelocityTracker.obtain();
        }
        this.f228s.addMovement(motionEvent);
        switch (actionMasked) {
            case 0:
                int x = (int) motionEvent.getX();
                this.f229t = (int) motionEvent.getY();
                View view = this.f217h != null ? (View) this.f217h.get() : null;
                if (view != null && coordinatorLayout.mo217a(view, x, this.f229t)) {
                    this.f218i = motionEvent.getPointerId(motionEvent.getActionIndex());
                    this.f219j = true;
                }
                this.f225p = this.f218i == -1 && !coordinatorLayout.mo217a((View) v, x, this.f229t);
                break;
            case 1:
            case 3:
                this.f219j = false;
                this.f218i = -1;
                if (this.f225p) {
                    this.f225p = false;
                    return false;
                }
                break;
        }
        if (!this.f225p && this.f214e.mo1277a(motionEvent)) {
            return true;
        }
        View view2 = (View) this.f217h.get();
        if (actionMasked != 2 || view2 == null || this.f225p || this.f213d == 1 || coordinatorLayout.mo217a(view2, (int) motionEvent.getX(), (int) motionEvent.getY()) || Math.abs(((float) this.f229t) - motionEvent.getY()) <= ((float) this.f214e.mo1273a())) {
            return false;
        }
        return true;
    }

    /* renamed from: b */
    public final boolean mo206b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f213d == 1 && actionMasked == 0) {
            return true;
        }
        this.f214e.mo1279b(motionEvent);
        if (actionMasked == 0) {
            m99b();
        }
        if (this.f228s == null) {
            this.f228s = VelocityTracker.obtain();
        }
        this.f228s.addMovement(motionEvent);
        if (actionMasked == 2 && !this.f225p && Math.abs(((float) this.f229t) - motionEvent.getY()) > ((float) this.f214e.mo1273a())) {
            this.f214e.mo1275a((View) v, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        if (!this.f225p) {
            return true;
        }
        return false;
    }

    /* renamed from: a */
    public final boolean mo189a(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
        this.f226q = 0;
        this.f227r = false;
        if ((i & 2) != 0) {
            return true;
        }
        return false;
    }

    /* renamed from: a */
    public final void mo184a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int[] iArr) {
        if (view == ((View) this.f217h.get())) {
            int top = v.getTop();
            int i2 = top - i;
            if (i > 0) {
                if (i2 < this.f210a) {
                    iArr[1] = top - this.f210a;
                    C0351ag.m1174c(v, -iArr[1]);
                    mo202a(3);
                } else {
                    iArr[1] = i;
                    C0351ag.m1174c(v, -i);
                    mo202a(1);
                }
            } else if (i < 0 && !C0351ag.m1170a(view, -1)) {
                if (i2 <= this.f211b || this.f212c) {
                    iArr[1] = i;
                    C0351ag.m1174c(v, -i);
                    mo202a(1);
                } else {
                    iArr[1] = top - this.f211b;
                    C0351ag.m1174c(v, -iArr[1]);
                    mo202a(4);
                }
            }
            v.getTop();
            mo201a();
            this.f226q = i;
            this.f227r = true;
        }
    }

    /* renamed from: a */
    public final void mo183a(CoordinatorLayout coordinatorLayout, V v, View view) {
        int i;
        int i2 = 3;
        if (v.getTop() == this.f210a) {
            mo202a(3);
        } else if (view == this.f217h.get() && this.f227r) {
            if (this.f226q > 0) {
                i = this.f210a;
            } else {
                if (this.f212c) {
                    this.f228s.computeCurrentVelocity(1000, this.f220k);
                    if (mo205a(v, this.f228s.getYVelocity(this.f218i))) {
                        i = this.f215f;
                        i2 = 5;
                    }
                }
                if (this.f226q == 0) {
                    int top = v.getTop();
                    if (Math.abs(top - this.f210a) < Math.abs(top - this.f211b)) {
                        i = this.f210a;
                    } else {
                        i = this.f211b;
                        i2 = 4;
                    }
                } else {
                    i = this.f211b;
                    i2 = 4;
                }
            }
            if (this.f214e.mo1278a((View) v, v.getLeft(), i)) {
                mo202a(2);
                C0351ag.m1166a((View) v, (Runnable) new C0034ad(this, v, i2));
            } else {
                mo202a(i2);
            }
            this.f227r = false;
        }
    }

    /* renamed from: a */
    public final boolean mo204a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        return view == this.f217h.get() && (this.f213d != 3 || super.mo204a(coordinatorLayout, v, view, f, f2));
    }

    /* renamed from: b */
    private void m100b(int i) {
        boolean z = true;
        if (i == -1) {
            if (!this.f222m) {
                this.f222m = true;
            }
            z = false;
        } else {
            if (this.f222m || this.f221l != i) {
                this.f222m = false;
                this.f221l = Math.max(0, i);
                this.f211b = this.f215f - i;
            }
            z = false;
        }
        if (z && this.f213d == 4 && this.f216g != null) {
            View view = (View) this.f216g.get();
            if (view != null) {
                view.requestLayout();
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo202a(int i) {
        if (this.f213d != i) {
            this.f213d = i;
            this.f216g.get();
        }
    }

    /* renamed from: b */
    private void m99b() {
        this.f218i = -1;
        if (this.f228s != null) {
            this.f228s.recycle();
            this.f228s = null;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final boolean mo205a(View view, float f) {
        if (this.f224o) {
            return true;
        }
        if (view.getTop() < this.f211b) {
            return false;
        }
        if (Math.abs((((float) view.getTop()) + (0.1f * f)) - ((float) this.f211b)) / ((float) this.f221l) <= 0.5f) {
            return false;
        }
        return true;
    }

    /* renamed from: b */
    private View m98b(View view) {
        if (C0351ag.m1194u(view)) {
            return view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View b = m98b(viewGroup.getChildAt(i));
                if (b != null) {
                    return b;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo201a() {
        this.f216g.get();
    }
}
