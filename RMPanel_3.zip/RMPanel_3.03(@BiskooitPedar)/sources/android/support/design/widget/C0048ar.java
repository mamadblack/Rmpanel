package android.support.design.widget;

/* renamed from: android.support.design.widget.ar */
public abstract class C0048ar {
}
