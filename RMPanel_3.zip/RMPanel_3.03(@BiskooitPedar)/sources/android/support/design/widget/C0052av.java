package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: android.support.design.widget.av */
final class C0052av extends AnimatorListenerAdapter {

    /* renamed from: a */
    final /* synthetic */ boolean f355a = false;

    /* renamed from: b */
    final /* synthetic */ C0056az f356b;

    /* renamed from: c */
    final /* synthetic */ C0050at f357c;

    C0052av(C0050at atVar, C0056az azVar) {
        this.f357c = atVar;
        this.f356b = azVar;
    }

    public final void onAnimationStart(Animator animator) {
        this.f357c.f345m.mo383a(0, this.f355a);
    }

    public final void onAnimationEnd(Animator animator) {
        this.f357c.f338b = 0;
    }
}
