package android.support.design.widget;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
/* renamed from: android.support.design.widget.ai */
public @interface C0039ai {
    /* renamed from: a */
    Class<? extends C0038ah> mo296a();
}
