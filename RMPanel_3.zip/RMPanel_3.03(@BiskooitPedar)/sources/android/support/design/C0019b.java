package android.support.design;

/* renamed from: android.support.design.b */
public final class C0019b {

    /* renamed from: a */
    public static final int design_snackbar_in = 2131034124;

    /* renamed from: b */
    public static final int design_snackbar_out = 2131034125;
}
