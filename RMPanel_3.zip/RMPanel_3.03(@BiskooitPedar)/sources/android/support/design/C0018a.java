package android.support.design;

/* renamed from: android.support.design.a */
public final class C0018a {
}
