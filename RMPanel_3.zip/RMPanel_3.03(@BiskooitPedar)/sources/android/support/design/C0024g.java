package android.support.design;

/* renamed from: android.support.design.g */
public final class C0024g {

    /* renamed from: a */
    public static final int app_bar_elevation_anim_duration = 2131492867;
}
