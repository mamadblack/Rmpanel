package android.support.design;

/* renamed from: android.support.design.c */
public final class C0020c {

    /* renamed from: a */
    public static final int state_collapsed = 2130772008;

    /* renamed from: b */
    public static final int state_collapsible = 2130772009;
}
