package android.support.design;

import com.premiereMind.GoldPanel.R;

/* renamed from: android.support.design.j */
public final class C0029j {

    /* renamed from: A */
    public static final int[] f112A = {R.attr.title, R.attr.expandedTitleMargin, R.attr.expandedTitleMarginStart, R.attr.expandedTitleMarginTop, R.attr.expandedTitleMarginEnd, R.attr.expandedTitleMarginBottom, R.attr.expandedTitleTextAppearance, R.attr.collapsedTitleTextAppearance, R.attr.contentScrim, R.attr.statusBarScrim, R.attr.toolbarId, R.attr.scrimVisibleHeightTrigger, R.attr.scrimAnimationDuration, R.attr.collapsedTitleGravity, R.attr.expandedTitleGravity, R.attr.titleEnabled};

    /* renamed from: B */
    public static final int[] f113B = {R.attr.layout_collapseMode, R.attr.layout_collapseParallaxMultiplier};

    /* renamed from: C */
    public static final int[] f114C = {16843173, 16843551, R.attr.alpha};

    /* renamed from: D */
    public static final int[] f115D = {16843015, R.attr.buttonTint, R.attr.buttonTintMode};

    /* renamed from: E */
    public static final int[] f116E = {R.attr.keylines, R.attr.statusBarBackground};

    /* renamed from: F */
    public static final int[] f117F = {16842931, R.attr.layout_behavior, R.attr.layout_anchor, R.attr.layout_keyline, R.attr.layout_anchorGravity, R.attr.layout_insetEdge, R.attr.layout_dodgeInsetEdges};

    /* renamed from: G */
    public static final int f118G = 0;

    /* renamed from: H */
    public static final int f119H = 2;

    /* renamed from: I */
    public static final int f120I = 4;

    /* renamed from: J */
    public static final int f121J = 1;

    /* renamed from: K */
    public static final int f122K = 6;

    /* renamed from: L */
    public static final int f123L = 5;

    /* renamed from: M */
    public static final int f124M = 3;

    /* renamed from: N */
    public static final int f125N = 0;

    /* renamed from: O */
    public static final int f126O = 1;

    /* renamed from: P */
    public static final int[] f127P = {R.attr.bottomSheetDialogTheme, R.attr.bottomSheetStyle, R.attr.textColorError};

    /* renamed from: Q */
    public static final int[] f128Q = {R.attr.color, R.attr.spinBars, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.thickness};

    /* renamed from: R */
    public static final int[] f129R = {R.attr.elevation, R.attr.rippleColor, R.attr.fabSize, R.attr.pressedTranslationZ, R.attr.borderWidth, R.attr.useCompatPadding, R.attr.backgroundTint, R.attr.backgroundTintMode};

    /* renamed from: S */
    public static final int[] f130S = {R.attr.behavior_autoHide};

    /* renamed from: T */
    public static final int f131T = 0;

    /* renamed from: U */
    public static final int[] f132U = {16843017, 16843264, R.attr.foregroundInsidePadding};

    /* renamed from: V */
    public static final int f133V = 0;

    /* renamed from: W */
    public static final int f134W = 1;

    /* renamed from: X */
    public static final int f135X = 2;

    /* renamed from: Y */
    public static final int[] f136Y = {16842927, 16842948, 16843046, 16843047, 16843048, R.attr.divider, R.attr.measureWithLargestChild, R.attr.showDividers, R.attr.dividerPadding};

    /* renamed from: Z */
    public static final int[] f137Z = {16842931, 16842996, 16842997, 16843137};

    /* renamed from: a */
    public static final int[] f138a = {R.attr.height, R.attr.title, R.attr.navigationMode, R.attr.displayOptions, R.attr.subtitle, R.attr.titleTextStyle, R.attr.subtitleTextStyle, R.attr.icon, R.attr.logo, R.attr.divider, R.attr.background, R.attr.backgroundStacked, R.attr.backgroundSplit, R.attr.customNavigationLayout, R.attr.homeLayout, R.attr.progressBarStyle, R.attr.indeterminateProgressStyle, R.attr.progressBarPadding, R.attr.itemPadding, R.attr.hideOnContentScroll, R.attr.contentInsetStart, R.attr.contentInsetEnd, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStartWithNavigation, R.attr.contentInsetEndWithActions, R.attr.elevation, R.attr.popupTheme, R.attr.homeAsUpIndicator};

    /* renamed from: aA */
    public static final int[] f139aA = {16842960, 16842994, 16842995};

    /* renamed from: aa */
    public static final int[] f140aa = {16843436, 16843437};

    /* renamed from: ab */
    public static final int[] f141ab = {16842766, 16842960, 16843156, 16843230, 16843231, 16843232};

    /* renamed from: ac */
    public static final int[] f142ac = {16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 16843236, 16843237, 16843375, R.attr.showAsAction, R.attr.actionLayout, R.attr.actionViewClass, R.attr.actionProviderClass, R.attr.contentDescription, R.attr.tooltipText};

    /* renamed from: ad */
    public static final int[] f143ad = {16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, R.attr.preserveIconSpacing, R.attr.subMenuArrow};

    /* renamed from: ae */
    public static final int[] f144ae = {16842964, 16842973, 16843039, R.attr.elevation, R.attr.menu, R.attr.itemIconTint, R.attr.itemTextColor, R.attr.itemBackground, R.attr.itemTextAppearance, R.attr.headerLayout};

    /* renamed from: af */
    public static final int[] f145af = {16843126, 16843465, R.attr.overlapAnchor};

    /* renamed from: ag */
    public static final int[] f146ag = {R.attr.state_above_anchor};

    /* renamed from: ah */
    public static final int[] f147ah = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};

    /* renamed from: ai */
    public static final int[] f148ai = {16842948, 16842993, R.attr.layoutManager, R.attr.spanCount, R.attr.reverseLayout, R.attr.stackFromEnd, R.attr.fastScrollEnabled, R.attr.fastScrollVerticalThumbDrawable, R.attr.fastScrollVerticalTrackDrawable, R.attr.fastScrollHorizontalThumbDrawable, R.attr.fastScrollHorizontalTrackDrawable};

    /* renamed from: aj */
    public static final int[] f149aj = {R.attr.insetForeground};

    /* renamed from: ak */
    public static final int[] f150ak = {R.attr.behavior_overlapTop};

    /* renamed from: al */
    public static final int f151al = 0;

    /* renamed from: am */
    public static final int[] f152am = {16842970, 16843039, 16843296, 16843364, R.attr.layout, R.attr.iconifiedByDefault, R.attr.queryHint, R.attr.defaultQueryHint, R.attr.closeIcon, R.attr.goIcon, R.attr.searchIcon, R.attr.searchHintIcon, R.attr.voiceIcon, R.attr.commitIcon, R.attr.suggestionRowLayout, R.attr.queryBackground, R.attr.submitBackground};

    /* renamed from: an */
    public static final int[] f153an = {16843039, R.attr.elevation, R.attr.maxActionInlineWidth};

    /* renamed from: ao */
    public static final int f154ao = 0;

    /* renamed from: ap */
    public static final int f155ap = 1;

    /* renamed from: aq */
    public static final int f156aq = 2;

    /* renamed from: ar */
    public static final int[] f157ar = {16842930, 16843126, 16843131, 16843362, R.attr.popupTheme};

    /* renamed from: as */
    public static final int[] f158as = {16843044, 16843045, 16843074, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode, R.attr.thumbTextPadding, R.attr.switchTextAppearance, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.splitTrack, R.attr.showText};

    /* renamed from: at */
    public static final int[] f159at = {16842754, 16842994, 16843087};

    /* renamed from: au */
    public static final int[] f160au = {R.attr.tabIndicatorColor, R.attr.tabIndicatorHeight, R.attr.tabContentStart, R.attr.tabBackground, R.attr.tabMode, R.attr.tabGravity, R.attr.tabMinWidth, R.attr.tabMaxWidth, R.attr.tabTextAppearance, R.attr.tabTextColor, R.attr.tabSelectedTextColor, R.attr.tabPaddingStart, R.attr.tabPaddingTop, R.attr.tabPaddingEnd, R.attr.tabPaddingBottom, R.attr.tabPadding};

    /* renamed from: av */
    public static final int[] f161av = {16842901, 16842902, 16842903, 16842904, 16842906, 16843105, 16843106, 16843107, 16843108, R.attr.textAllCaps};

    /* renamed from: aw */
    public static final int[] f162aw = {16842906, 16843088, R.attr.hintTextAppearance, R.attr.hintEnabled, R.attr.errorEnabled, R.attr.errorTextAppearance, R.attr.counterEnabled, R.attr.counterMaxLength, R.attr.counterTextAppearance, R.attr.counterOverflowTextAppearance, R.attr.hintAnimationEnabled, R.attr.passwordToggleEnabled, R.attr.passwordToggleDrawable, R.attr.passwordToggleContentDescription, R.attr.passwordToggleTint, R.attr.passwordToggleTintMode};

    /* renamed from: ax */
    public static final int[] f163ax = {16842927, 16843072, R.attr.title, R.attr.subtitle, R.attr.logo, R.attr.contentInsetStart, R.attr.contentInsetEnd, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStartWithNavigation, R.attr.contentInsetEndWithActions, R.attr.popupTheme, R.attr.titleTextAppearance, R.attr.subtitleTextAppearance, R.attr.titleMargin, R.attr.titleMarginStart, R.attr.titleMarginEnd, R.attr.titleMarginTop, R.attr.titleMarginBottom, R.attr.titleMargins, R.attr.maxButtonHeight, R.attr.buttonGravity, R.attr.collapseIcon, R.attr.collapseContentDescription, R.attr.navigationIcon, R.attr.navigationContentDescription, R.attr.logoDescription, R.attr.titleTextColor, R.attr.subtitleTextColor};

    /* renamed from: ay */
    public static final int[] f164ay = {16842752, 16842970, R.attr.paddingStart, R.attr.paddingEnd, R.attr.theme};

    /* renamed from: az */
    public static final int[] f165az = {16842964, R.attr.backgroundTint, R.attr.backgroundTintMode};

    /* renamed from: b */
    public static final int[] f166b = {16842931};

    /* renamed from: c */
    public static final int[] f167c = {16843071};

    /* renamed from: d */
    public static final int[] f168d = new int[0];

    /* renamed from: e */
    public static final int[] f169e = {R.attr.height, R.attr.titleTextStyle, R.attr.subtitleTextStyle, R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout};

    /* renamed from: f */
    public static final int[] f170f = {R.attr.initialActivityCount, R.attr.expandActivityOverflowButtonDrawable};

    /* renamed from: g */
    public static final int[] f171g = {16842994, R.attr.buttonPanelSideLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.singleChoiceItemLayout, R.attr.listItemLayout, R.attr.showTitle};

    /* renamed from: h */
    public static final int[] f172h = {16842964, R.attr.elevation, R.attr.expanded};

    /* renamed from: i */
    public static final int[] f173i = {R.attr.state_collapsed, R.attr.state_collapsible};

    /* renamed from: j */
    public static final int[] f174j = {R.attr.layout_scrollFlags, R.attr.layout_scrollInterpolator};

    /* renamed from: k */
    public static final int f175k = 0;

    /* renamed from: l */
    public static final int f176l = 1;

    /* renamed from: m */
    public static final int f177m = 0;

    /* renamed from: n */
    public static final int f178n = 1;

    /* renamed from: o */
    public static final int f179o = 2;

    /* renamed from: p */
    public static final int[] f180p = {16843033, R.attr.srcCompat};

    /* renamed from: q */
    public static final int[] f181q = {16843074, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};

    /* renamed from: r */
    public static final int[] f182r = {16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667};

    /* renamed from: s */
    public static final int[] f183s = {16842804, R.attr.textAllCaps};

    /* renamed from: t */
    public static final int[] f184t = {16842839, 16842926, R.attr.windowActionBar, R.attr.windowNoTitle, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedWidthMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMinor, R.attr.windowFixedHeightMajor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.actionBarTabStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabTextStyle, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.actionBarPopupTheme, R.attr.actionBarStyle, R.attr.actionBarSplitStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionBarSize, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeStyle, R.attr.actionModeCloseButtonStyle, R.attr.actionModeBackground, R.attr.actionModeSplitBackground, R.attr.actionModeCloseDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModePasteDrawable, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeFindDrawable, R.attr.actionModeWebSearchDrawable, R.attr.actionModePopupWindowStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceSmallPopupMenu, R.attr.textAppearancePopupMenuHeader, R.attr.dialogTheme, R.attr.dialogPreferredPadding, R.attr.listDividerAlertDialog, R.attr.actionDropDownStyle, R.attr.dropdownListPreferredItemHeight, R.attr.spinnerDropDownItemStyle, R.attr.homeAsUpIndicator, R.attr.actionButtonStyle, R.attr.buttonBarStyle, R.attr.buttonBarButtonStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.borderlessButtonStyle, R.attr.dividerVertical, R.attr.dividerHorizontal, R.attr.activityChooserViewStyle, R.attr.toolbarStyle, R.attr.toolbarNavigationButtonStyle, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.editTextColor, R.attr.editTextBackground, R.attr.imageButtonStyle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSearchResultSubtitle, R.attr.textColorSearchUrl, R.attr.searchViewStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.dropDownListViewStyle, R.attr.listPopupWindowStyle, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSmall, R.attr.panelBackground, R.attr.panelMenuListWidth, R.attr.panelMenuListTheme, R.attr.listChoiceBackgroundIndicator, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorAccent, R.attr.colorControlNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorButtonNormal, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.colorBackgroundFloating, R.attr.alertDialogStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogTheme, R.attr.textColorAlertDialogListItem, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.autoCompleteTextViewStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.editTextStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.seekBarStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.listMenuViewStyle};

    /* renamed from: u */
    public static final int[] f185u = {R.attr.elevation, R.attr.menu, R.attr.itemIconTint, R.attr.itemTextColor, R.attr.itemBackground};

    /* renamed from: v */
    public static final int[] f186v = {R.attr.behavior_peekHeight, R.attr.behavior_hideable, R.attr.behavior_skipCollapsed};

    /* renamed from: w */
    public static final int f187w = 1;

    /* renamed from: x */
    public static final int f188x = 0;

    /* renamed from: y */
    public static final int f189y = 2;

    /* renamed from: z */
    public static final int[] f190z = {R.attr.allowStacking};
}
