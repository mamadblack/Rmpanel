package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.design.C0029j;
import android.support.p018v7.widget.LinearLayoutCompat;
import android.util.AttributeSet;
import android.view.Gravity;

/* renamed from: android.support.design.internal.a */
public class C0027a extends LinearLayoutCompat {

    /* renamed from: a */
    protected boolean f105a;

    /* renamed from: b */
    boolean f106b;

    /* renamed from: c */
    private Drawable f107c;

    /* renamed from: d */
    private final Rect f108d;

    /* renamed from: e */
    private final Rect f109e;

    /* renamed from: f */
    private int f110f;

    public C0027a(Context context) {
        this(context, null);
    }

    public C0027a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0027a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f108d = new Rect();
        this.f109e = new Rect();
        this.f110f = 119;
        this.f105a = true;
        this.f106b = false;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0029j.f132U, i, 0);
        this.f110f = obtainStyledAttributes.getInt(C0029j.f134W, this.f110f);
        Drawable drawable = obtainStyledAttributes.getDrawable(C0029j.f133V);
        if (drawable != null) {
            setForeground(drawable);
        }
        this.f105a = obtainStyledAttributes.getBoolean(C0029j.f135X, true);
        obtainStyledAttributes.recycle();
    }

    public int getForegroundGravity() {
        return this.f110f;
    }

    public void setForegroundGravity(int i) {
        int i2;
        if (this.f110f != i) {
            if ((8388615 & i) == 0) {
                i2 = 8388611 | i;
            } else {
                i2 = i;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.f110f = i2;
            if (this.f110f == 119 && this.f107c != null) {
                this.f107c.getPadding(new Rect());
            }
            requestLayout();
        }
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f107c;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        if (this.f107c != null) {
            this.f107c.jumpToCurrentState();
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f107c != null && this.f107c.isStateful()) {
            this.f107c.setState(getDrawableState());
        }
    }

    public void setForeground(Drawable drawable) {
        if (this.f107c != drawable) {
            if (this.f107c != null) {
                this.f107c.setCallback(null);
                unscheduleDrawable(this.f107c);
            }
            this.f107c = drawable;
            if (drawable != null) {
                setWillNotDraw(false);
                drawable.setCallback(this);
                if (drawable.isStateful()) {
                    drawable.setState(getDrawableState());
                }
                if (this.f110f == 119) {
                    drawable.getPadding(new Rect());
                }
            } else {
                setWillNotDraw(true);
            }
            requestLayout();
            invalidate();
        }
    }

    public Drawable getForeground() {
        return this.f107c;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f106b |= z;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.f106b = true;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f107c != null) {
            Drawable drawable = this.f107c;
            if (this.f106b) {
                this.f106b = false;
                Rect rect = this.f108d;
                Rect rect2 = this.f109e;
                int right = getRight() - getLeft();
                int bottom = getBottom() - getTop();
                if (this.f105a) {
                    rect.set(0, 0, right, bottom);
                } else {
                    rect.set(getPaddingLeft(), getPaddingTop(), right - getPaddingRight(), bottom - getPaddingBottom());
                }
                Gravity.apply(this.f110f, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), rect, rect2);
                drawable.setBounds(rect2);
            }
            drawable.draw(canvas);
        }
    }

    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        if (this.f107c != null) {
            this.f107c.setHotspot(f, f2);
        }
    }
}
