package android.support.design.internal;

import android.content.Context;
import android.support.p018v7.view.menu.C0599ag;
import android.support.p018v7.view.menu.C0621o;
import android.support.p018v7.widget.C0758ep;
import android.support.p018v7.widget.LinearLayoutManager;
import android.support.p018v7.widget.RecyclerView;
import android.util.AttributeSet;

public class NavigationMenuView extends RecyclerView implements C0599ag {
    public NavigationMenuView(Context context) {
        this(context, null);
    }

    public NavigationMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        mo2170a((C0758ep) new LinearLayoutManager(context, 1, false));
    }

    /* renamed from: a */
    public final void mo138a(C0621o oVar) {
    }
}
