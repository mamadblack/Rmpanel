package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.design.C0021d;
import android.support.design.C0023f;
import android.support.design.C0029j;
import android.support.design.widget.C0104w;
import android.support.p003v4.p014g.C0351ag;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SnackbarContentLayout extends LinearLayout implements C0104w {

    /* renamed from: a */
    private TextView f101a;

    /* renamed from: b */
    private Button f102b;

    /* renamed from: c */
    private int f103c;

    /* renamed from: d */
    private int f104d;

    public SnackbarContentLayout(Context context) {
        this(context, null);
    }

    public SnackbarContentLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0029j.f153an);
        this.f103c = obtainStyledAttributes.getDimensionPixelSize(C0029j.f154ao, -1);
        this.f104d = obtainStyledAttributes.getDimensionPixelSize(C0029j.f156aq, -1);
        obtainStyledAttributes.recycle();
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f101a = (TextView) findViewById(C0023f.snackbar_text);
        this.f102b = (Button) findViewById(C0023f.snackbar_action);
    }

    /* renamed from: a */
    public final TextView mo139a() {
        return this.f101a;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        boolean z;
        super.onMeasure(i, i2);
        if (this.f103c > 0 && getMeasuredWidth() > this.f103c) {
            i = MeasureSpec.makeMeasureSpec(this.f103c, 1073741824);
            super.onMeasure(i, i2);
        }
        int dimensionPixelSize = getResources().getDimensionPixelSize(C0021d.design_snackbar_padding_vertical_2lines);
        int dimensionPixelSize2 = getResources().getDimensionPixelSize(C0021d.design_snackbar_padding_vertical);
        boolean z2 = this.f101a.getLayout().getLineCount() > 1;
        if (!z2 || this.f104d <= 0 || this.f102b.getMeasuredWidth() <= this.f104d) {
            if (!z2) {
                dimensionPixelSize = dimensionPixelSize2;
            }
            if (m42a(0, dimensionPixelSize, dimensionPixelSize)) {
                z = true;
            }
            z = false;
        } else {
            if (m42a(1, dimensionPixelSize, dimensionPixelSize - dimensionPixelSize2)) {
                z = true;
            }
            z = false;
        }
        if (z) {
            super.onMeasure(i, i2);
        }
    }

    /* renamed from: a */
    private boolean m42a(int i, int i2, int i3) {
        boolean z = false;
        if (i != getOrientation()) {
            setOrientation(i);
            z = true;
        }
        if (this.f101a.getPaddingTop() == i2 && this.f101a.getPaddingBottom() == i3) {
            return z;
        }
        TextView textView = this.f101a;
        if (C0351ag.m1191r(textView)) {
            C0351ag.m1159a(textView, C0351ag.m1180g(textView), i2, C0351ag.m1181h(textView), i3);
        } else {
            textView.setPadding(textView.getPaddingLeft(), i2, textView.getPaddingRight(), i3);
        }
        return true;
    }

    /* renamed from: b */
    public final void mo140b() {
        this.f101a.setAlpha(0.0f);
        this.f101a.animate().alpha(1.0f).setDuration(180).setStartDelay(70).start();
        if (this.f102b.getVisibility() == 0) {
            this.f102b.setAlpha(0.0f);
            this.f102b.animate().alpha(1.0f).setDuration(180).setStartDelay(70).start();
        }
    }

    /* renamed from: c */
    public final void mo141c() {
        this.f101a.setAlpha(1.0f);
        this.f101a.animate().alpha(0.0f).setDuration(180).setStartDelay(0).start();
        if (this.f102b.getVisibility() == 0) {
            this.f102b.setAlpha(1.0f);
            this.f102b.animate().alpha(0.0f).setDuration(180).setStartDelay(0).start();
        }
    }
}
