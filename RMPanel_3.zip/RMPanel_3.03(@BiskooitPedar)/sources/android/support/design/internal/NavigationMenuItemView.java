package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.StateListDrawable;
import android.support.design.C0021d;
import android.support.design.C0022e;
import android.support.design.C0023f;
import android.support.design.C0025h;
import android.support.p003v4.p004a.p005a.C0109a;
import android.support.p003v4.p006b.p007a.C0238a;
import android.support.p003v4.p014g.C0351ag;
import android.support.p003v4.p014g.C0403d;
import android.support.p003v4.widget.C0446an;
import android.support.p018v7.p019a.C0484b;
import android.support.p018v7.view.menu.C0600ah;
import android.support.p018v7.view.menu.C0625s;
import android.support.p018v7.widget.C0718dc;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;

public class NavigationMenuItemView extends C0027a implements C0600ah {

    /* renamed from: d */
    private static final int[] f90d = {16842912};

    /* renamed from: c */
    boolean f91c;

    /* renamed from: e */
    private final int f92e;

    /* renamed from: f */
    private boolean f93f;

    /* renamed from: g */
    private final CheckedTextView f94g;

    /* renamed from: h */
    private FrameLayout f95h;

    /* renamed from: i */
    private C0625s f96i;

    /* renamed from: j */
    private ColorStateList f97j;

    /* renamed from: k */
    private boolean f98k;

    /* renamed from: l */
    private Drawable f99l;

    /* renamed from: m */
    private final C0403d f100m;

    public NavigationMenuItemView(Context context) {
        this(context, null);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f100m = new C0028b(this);
        mo2133c(0);
        LayoutInflater.from(context).inflate(C0025h.design_navigation_menu_item, this, true);
        this.f92e = context.getResources().getDimensionPixelSize(C0021d.design_navigation_icon_size);
        this.f94g = (CheckedTextView) findViewById(C0023f.design_menu_item_text);
        this.f94g.setDuplicateParentStateEnabled(true);
        C0351ag.m1164a((View) this.f94g, this.f100m);
    }

    /* renamed from: a */
    public final void mo135a(C0625s sVar) {
        boolean z;
        StateListDrawable stateListDrawable;
        this.f96i = sVar;
        setVisibility(sVar.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(C0484b.colorControlHighlight, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(f90d, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            C0351ag.m1162a((View) this, (Drawable) stateListDrawable);
        }
        boolean isCheckable = sVar.isCheckable();
        refreshDrawableState();
        if (this.f91c != isCheckable) {
            this.f91c = isCheckable;
            C0403d.m1373a((View) this.f94g, 2048);
        }
        boolean isChecked = sVar.isChecked();
        refreshDrawableState();
        this.f94g.setChecked(isChecked);
        setEnabled(sVar.isEnabled());
        this.f94g.setText(sVar.getTitle());
        Drawable icon = sVar.getIcon();
        if (icon != null) {
            if (this.f98k) {
                ConstantState constantState = icon.getConstantState();
                if (constantState != null) {
                    icon = constantState.newDrawable();
                }
                icon = C0238a.m808f(icon).mutate();
                C0238a.m798a(icon, this.f97j);
            }
            icon.setBounds(0, 0, this.f92e, this.f92e);
        } else if (this.f93f) {
            if (this.f99l == null) {
                this.f99l = C0109a.m349a(getResources(), C0022e.navigation_empty_icon, getContext().getTheme());
                if (this.f99l != null) {
                    this.f99l.setBounds(0, 0, this.f92e, this.f92e);
                }
            }
            icon = this.f99l;
        }
        C0446an.m1491a(this.f94g, icon);
        View actionView = sVar.getActionView();
        if (actionView != null) {
            if (this.f95h == null) {
                this.f95h = (FrameLayout) ((ViewStub) findViewById(C0023f.design_menu_item_action_area_stub)).inflate();
            }
            this.f95h.removeAllViews();
            this.f95h.addView(actionView);
        }
        setContentDescription(sVar.getContentDescription());
        C0351ag.m1165a((View) this, sVar.getTooltipText());
        if (this.f96i.getTitle() == null && this.f96i.getIcon() == null && this.f96i.getActionView() != null) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            this.f94g.setVisibility(8);
            if (this.f95h != null) {
                C0718dc dcVar = (C0718dc) this.f95h.getLayoutParams();
                dcVar.width = -1;
                this.f95h.setLayoutParams(dcVar);
                return;
            }
            return;
        }
        this.f94g.setVisibility(0);
        if (this.f95h != null) {
            C0718dc dcVar2 = (C0718dc) this.f95h.getLayoutParams();
            dcVar2.width = -2;
            this.f95h.setLayoutParams(dcVar2);
        }
    }

    /* renamed from: a */
    public final C0625s mo134a() {
        return this.f96i;
    }

    /* renamed from: b */
    public final boolean mo136b() {
        return false;
    }

    /* access modifiers changed from: protected */
    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (this.f96i != null && this.f96i.isCheckable() && this.f96i.isChecked()) {
            mergeDrawableStates(onCreateDrawableState, f90d);
        }
        return onCreateDrawableState;
    }
}
