package android.support.design.internal;

import android.support.p003v4.p014g.C0403d;
import android.support.p003v4.p014g.p015a.C0330l;
import android.view.View;

/* renamed from: android.support.design.internal.b */
final class C0028b extends C0403d {

    /* renamed from: a */
    final /* synthetic */ NavigationMenuItemView f111a;

    C0028b(NavigationMenuItemView navigationMenuItemView) {
        this.f111a = navigationMenuItemView;
    }

    /* renamed from: a */
    public final void mo155a(View view, C0330l lVar) {
        super.mo155a(view, lVar);
        lVar.mo988a(this.f111a.f91c);
    }
}
