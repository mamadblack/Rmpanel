package android.support.design;

/* renamed from: android.support.design.i */
public final class C0026i {

    /* renamed from: a */
    public static final int Widget_Design_AppBarLayout = 2131361940;

    /* renamed from: b */
    public static final int Widget_Design_CoordinatorLayout = 2131362174;
}
