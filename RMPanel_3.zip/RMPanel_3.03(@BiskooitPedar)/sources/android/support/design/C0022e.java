package android.support.design;

/* renamed from: android.support.design.e */
public final class C0022e {

    /* renamed from: a */
    public static final int navigation_empty_icon = 2130837657;
}
